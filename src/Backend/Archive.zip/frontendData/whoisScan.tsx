export const whoisScanOutput = [
    {   
        scanId: '',
        output:``
    },

{
scanId: 'wzWSaCvLiFghaXkTcLxCS',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'SCHrdbVfxQfKtIqwsPJcn',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'fWhdMxLFQjsqmAKORTNWr',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'RhIsIwnuhMZvzrIGSDWuE',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'nFUeBzyfRvKZgEmNaMHsu',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'nFUeBzyfRvKZgEmNaMHsu',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'cwoqfvtiBVffSqzfInOIV',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'isyrhXKfLoEdzwSuePUWU',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'isyrhXKfLoEdzwSuePUWU',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'MvkiHdNEZmUoEOdqRByXq',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'QfREPonKfiqssBmOrajnO',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'AUXWStsPdWJtoJuvDlaKV',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'wiUKkStrllsdRdICKtLNl',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'sLCxuqBRQKgCrGXMStfUR',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'atZeZzZzvpKskMKcaqAQi',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'IuJmIHyFwwFdIKJMvhdzW',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'KyDYmQcvGiRwvHJCNlwvF',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'QQXTTrrApJpOtrRunYXKO',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'KtuDiWAPWlKdkIVitwFBU',
output:`
Enable WhoIs feature to discover.
`},


{
scanId: 'jmuuNynwBDgrDPObSFuLu',
output:`
Enable WhoIs feature to discover.
`},

]