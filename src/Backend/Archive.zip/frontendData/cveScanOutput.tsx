export const cveScanOutput = [

    {

        scanId: "",

        output: "",

    },


{
scanId: 'wzWSaCvLiFghaXkTcLxCS',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'SCHrdbVfxQfKtIqwsPJcn',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'fWhdMxLFQjsqmAKORTNWr',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'cwoqfvtiBVffSqzfInOIV',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'isyrhXKfLoEdzwSuePUWU',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'isyrhXKfLoEdzwSuePUWU',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'MvkiHdNEZmUoEOdqRByXq',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'VFdSxpDHAAIamGuQCPpjP',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'QfREPonKfiqssBmOrajnO',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'atZeZzZzvpKskMKcaqAQi',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'IuJmIHyFwwFdIKJMvhdzW',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'KyDYmQcvGiRwvHJCNlwvF',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'QQXTTrrApJpOtrRunYXKO',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'KtuDiWAPWlKdkIVitwFBU',
output:`
Enable CVE detection to discover.
`},


{
scanId: 'jmuuNynwBDgrDPObSFuLu',
output:`
Enable CVE detection to discover.
`},

]