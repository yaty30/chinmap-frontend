interface Data {scanId: string, portno: string, port: string, status: string, service: string,}

function createData(scanId: string, portno: string, port: string, status: string, service: string, ): Data {return { scanId, portno, port, status, service };}

export const rows = [
    createData('','','','','',),

// ===================== Target: 192.168.1.1 ================================
createData('ruDdYMRlcpymMchTZzJFJ','53', 'tcp', 'open', 'domain'),
createData('ruDdYMRlcpymMchTZzJFJ','80', 'tcp', 'open', 'http'),
createData('ruDdYMRlcpymMchTZzJFJ','548', 'tcp', 'open', 'afp'),
createData('ruDdYMRlcpymMchTZzJFJ','631', 'tcp', 'open', 'ipp'),
createData('ruDdYMRlcpymMchTZzJFJ','5000', 'tcp', 'open', 'upnp'),
// ===================== END of 192.168.1.1 =================================

// ===================== Target: 192.168.1.1 ================================
createData('wzWSaCvLiFghaXkTcLxCS','53', 'tcp', 'open', 'domain'),
createData('wzWSaCvLiFghaXkTcLxCS','80', 'tcp', 'open', 'http'),
createData('wzWSaCvLiFghaXkTcLxCS','548', 'tcp', 'open', 'afp'),
createData('wzWSaCvLiFghaXkTcLxCS','631', 'tcp', 'open', 'ipp'),
createData('wzWSaCvLiFghaXkTcLxCS','5000', 'tcp', 'open', 'upnp'),
// ===================== END of 192.168.1.1 =================================

// ===================== Target: 192.168.1.1 ================================
createData('SCHrdbVfxQfKtIqwsPJcn','53', 'tcp', 'open', 'domain'),
createData('SCHrdbVfxQfKtIqwsPJcn','80', 'tcp', 'open', 'http'),
createData('SCHrdbVfxQfKtIqwsPJcn','548', 'tcp', 'open', 'afp'),
createData('SCHrdbVfxQfKtIqwsPJcn','631', 'tcp', 'open', 'ipp'),
createData('SCHrdbVfxQfKtIqwsPJcn','5000', 'tcp', 'open', 'upnp'),
// ===================== END of 192.168.1.1 =================================

// ===================== Target: scanme.nmap.org ================================
createData('fWhdMxLFQjsqmAKORTNWr','22', 'tcp', 'open', 'ssh'),
createData('fWhdMxLFQjsqmAKORTNWr','80', 'tcp', 'open', 'http'),
createData('fWhdMxLFQjsqmAKORTNWr','9929', 'tcp', 'open', 'nping-echo'),
createData('fWhdMxLFQjsqmAKORTNWr','31337', 'tcp', 'open', 'Elite'),
// ===================== END of scanme.nmap.org =================================

// ===================== Target: 192.168.1.1 ================================
createData('IuJmIHyFwwFdIKJMvhdzW','53', 'tcp', 'open', 'domain'),
createData('IuJmIHyFwwFdIKJMvhdzW','80', 'tcp', 'open', 'http'),
createData('IuJmIHyFwwFdIKJMvhdzW','548', 'tcp', 'open', 'afp'),
createData('IuJmIHyFwwFdIKJMvhdzW','631', 'tcp', 'open', 'ipp'),
createData('IuJmIHyFwwFdIKJMvhdzW','5000', 'tcp', 'open', 'upnp'),
createData('IuJmIHyFwwFdIKJMvhdzW','8200', 'tcp', 'open', 'trivnet1'),
createData('IuJmIHyFwwFdIKJMvhdzW','20005', 'tcp', 'open', 'btx'),
// ===================== END of 192.168.1.1 =================================

// ===================== Target: 192.168.1.1 ================================
createData('KyDYmQcvGiRwvHJCNlwvF','53', 'tcp', 'open', 'domain'),
createData('KyDYmQcvGiRwvHJCNlwvF','80', 'tcp', 'open', 'http'),
createData('KyDYmQcvGiRwvHJCNlwvF','548', 'tcp', 'open', 'afp'),
createData('KyDYmQcvGiRwvHJCNlwvF','631', 'tcp', 'open', 'ipp'),
createData('KyDYmQcvGiRwvHJCNlwvF','5000', 'tcp', 'open', 'upnp'),
createData('KyDYmQcvGiRwvHJCNlwvF','8200', 'tcp', 'open', 'trivnet1'),
createData('KyDYmQcvGiRwvHJCNlwvF','20005', 'tcp', 'open', 'btx'),
// ===================== END of 192.168.1.1 =================================

// ===================== Target: 192.168.1.1 ================================
createData('KtuDiWAPWlKdkIVitwFBU','53', 'tcp', 'open', 'domain'),
createData('KtuDiWAPWlKdkIVitwFBU','80', 'tcp', 'open', 'http'),
createData('KtuDiWAPWlKdkIVitwFBU','548', 'tcp', 'open', 'afp'),
createData('KtuDiWAPWlKdkIVitwFBU','631', 'tcp', 'open', 'ipp'),
createData('KtuDiWAPWlKdkIVitwFBU','5000', 'tcp', 'open', 'upnp'),
createData('KtuDiWAPWlKdkIVitwFBU','8200', 'tcp', 'open', 'trivnet1'),
createData('KtuDiWAPWlKdkIVitwFBU','20005', 'tcp', 'open', 'btx'),
// ===================== END of 192.168.1.1 =================================

// ===================== Target: 192.168.1.1 ================================
createData('jmuuNynwBDgrDPObSFuLu','53', 'tcp', 'open', 'domain'),
createData('jmuuNynwBDgrDPObSFuLu','80', 'tcp', 'open', 'http'),
createData('jmuuNynwBDgrDPObSFuLu','548', 'tcp', 'open', 'afp'),
createData('jmuuNynwBDgrDPObSFuLu','631', 'tcp', 'open', 'ipp'),
createData('jmuuNynwBDgrDPObSFuLu','5000', 'tcp', 'open', 'upnp'),
createData('jmuuNynwBDgrDPObSFuLu','8200', 'tcp', 'open', 'trivnet1'),
createData('jmuuNynwBDgrDPObSFuLu','20005', 'tcp', 'open', 'btx'),
// ===================== END of 192.168.1.1 =================================
]